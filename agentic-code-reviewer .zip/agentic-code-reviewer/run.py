#!/usr/bin/env python3
"""
Agentic Code Reviewer -- CLI entrypoint.

Usage:
    python run.py --repo https://github.com/owner/repo
    python run.py --repo owner/repo --output-dir transcripts --tag demo1

See README.md for full setup and run instructions.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from datetime import datetime, timezone

from agent.orchestrator import Orchestrator
from agent import report


def build_logger(log_path: str) -> logging.Logger:
    logger = logging.getLogger("agent")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    fmt = logging.Formatter("%(asctime)s | %(levelname)-7s | %(message)s",
                             datefmt="%H:%M:%S")

    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(fmt)
    logger.addHandler(console)

    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setFormatter(fmt)
    logger.addHandler(file_handler)

    return logger


def main():
    parser = argparse.ArgumentParser(description="Agentic GitHub code-quality reviewer")
    parser.add_argument("--repo", required=True,
                         help="GitHub repo, e.g. 'owner/repo' or full URL")
    parser.add_argument("--output-dir", default="transcripts",
                         help="Where to write the log + report files")
    parser.add_argument("--tag", default=None,
                         help="Short label for this run's output filenames")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    tag = args.tag or timestamp
    log_path = os.path.join(args.output_dir, f"{tag}.log")

    logger = build_logger(log_path)

    goal = f"Review the code quality of the GitHub repository '{args.repo}' and suggest fixes."
    orchestrator = Orchestrator()
    result = orchestrator.run(goal=goal, repo_url=args.repo)

    md_path = os.path.join(args.output_dir, f"{tag}.report.md")
    json_path = os.path.join(args.output_dir, f"{tag}.report.json")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(report.to_markdown(result))
    with open(json_path, "w", encoding="utf-8") as f:
        f.write(report.to_json(result))

    print(f"\nLog:            {log_path}")
    print(f"Markdown report: {md_path}")
    print(f"JSON report:     {json_path}")
    sys.exit(0 if result.success else 1)


if __name__ == "__main__":
    main()
