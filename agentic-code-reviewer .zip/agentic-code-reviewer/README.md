# Agentic Code Reviewer

A small agentic AI system that takes a GitHub repository URL as a goal,
**plans** how to review it, **uses real tools** to fetch and analyze the
actual code, **self-corrects** when something goes wrong, and produces a
structured quality report.

Built for the Agentic AI Engineer Intern take-home assignment.

## What it actually does (no mocked data)

- Fetches **real** repository data from the live GitHub API (`api.github.com`, `raw.githubusercontent.com`)
- Runs **real** static analysis using Python's built-in `ast` parser (not a keyword search)
- Computes a real weighted quality score from the findings
- Every run produces a log transcript + a Markdown report + a JSON report

No API key is required to run it. See "Optional: LLM-assisted planning" below for the one part that can optionally use one.

## Setup

Requires Python 3.10+.

```bash
cd agentic-code-reviewer
pip install -r requirements.txt
```

## Run it

```bash
python run.py --repo https://github.com/psf/requests
```

or just `owner/repo`:

```bash
python run.py --repo psf/requests --tag my_first_run
```

Output goes to `transcripts/` by default:
- `<tag>.log` — full run transcript (plan, every tool call, every decision)
- `<tag>.report.md` — human-readable report
- `<tag>.report.json` — machine-readable report

### Try the failure cases yourself

```bash
# Repo doesn't exist -> graceful, explained failure (not a crash)
python run.py --repo "github.com/this-repo/does-not-exist-xyz"

# A big real repo, to see filtering/capping in action
python run.py --repo https://github.com/pallets/flask
```

## Run the tests

```bash
pip install pytest
python -m pytest tests/ -v
```

19 unit tests covering the analyzer's rules, the scoring math, and URL parsing edge cases — all fast and offline (no network calls in tests).

## Project layout

```
agent/
  planner.py          # decomposes the goal into a visible, explained plan
  orchestrator.py      # executes the plan, retries, self-corrects, logs
  report.py            # builds the final Markdown + JSON report
  tools/
    github_tool.py     # Tool 1: live GitHub data (repo, file tree, file contents)
    analyzer_tool.py   # Tool 2: real ast-based static analysis ("code executor")
    calculator_tool.py # Tool 3: aggregates issues into a 0-100 score
run.py                  # CLI entrypoint
tests/                  # pytest unit tests
transcripts/            # sample run logs + reports (see below)
architecture.png        # architecture diagram
WRITEUP.md              # design decisions, limitations, what I'd do differently
```

## Sample transcripts included

| File | What it demonstrates |
|---|---|
| `transcripts/demo1_real_repo.*` | Full happy-path run against a real, large repo (`psf/requests`) |
| `transcripts/demo2_nonexistent_repo.*` | Deliberately induced failure: repo doesn't exist → graceful, explained failure report instead of a crash |
| `transcripts/demo3_self_correction.log` | Deliberately induced failure: agent requests a guessed filename that 404s, recovers via fallback candidates |

## Optional: LLM-assisted planning

By default the `Planner` uses a deterministic, template-based plan (see
`agent/planner.py`) — this makes the whole project runnable by anyone with
zero setup and zero API cost, and it never silently degrades.

If you export a real Anthropic API key:

```bash
export ANTHROPIC_API_KEY=sk-ant-...
python run.py --repo psf/requests
```

the planner will instead ask Claude to generate the plan dynamically. If
that call fails for any reason (network, bad response), it **automatically
falls back** to the deterministic plan rather than crashing — this fallback
is itself one more self-correction path in the system.

## Design assumptions (see WRITEUP.md for the full write-up)

- Only `.py` files are analyzed (documented scope limit, not a hidden bug)
- Review is capped at 12 files per repo to keep runs fast for a demo
- Files over 60KB are skipped (likely generated/vendored code, not hand-written)
- No GitHub token is used, so runs are subject to GitHub's public rate limit
  (60 req/hr) — mitigated by using one recursive tree call plus the
  unmetered raw-content CDN instead of the per-file metered API
