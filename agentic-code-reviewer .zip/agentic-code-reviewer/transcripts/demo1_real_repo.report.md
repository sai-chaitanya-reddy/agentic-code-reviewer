# Code Quality Report

**Goal:** Review the code quality of the GitHub repository 'https://github.com/psf/requests' and suggest fixes.

**Status:** ✅ Success  **Duration:** 1.51s

## Repository

- **Name:** psf/requests
- **Description:** A simple, yet elegant, HTTP library.
- **Primary language:** Python
- **Stars:** 54346

## Overall Quality Score: **99.8/100**

## Per-file Scores

| File | Score | Issues |
|---|---|---|
| `src/requests/auth.py` | 99.2 | 8 |
| `src/requests/adapters.py` | 99.3 | 7 |
| `src/requests/api.py` | 99.4 | 4 |
| `src/requests/_types.py` | 99.7 | 2 |
| `src/requests/__init__.py` | 99.9 | 1 |
| `docs/_themes/flask_theme_support.py` | 100.0 | 0 |
| `docs/conf.py` | 100.0 | 0 |
| `setup.py` | 100.0 | 0 |
| `src/requests/__version__.py` | 100.0 | 0 |
| `src/requests/_internal_utils.py` | 100.0 | 0 |
| `src/requests/certs.py` | 100.0 | 0 |
| `src/requests/compat.py` | 100.0 | 0 |

## Issues Found

### `src/requests/__init__.py`

- 🟡 **line 60** [missing-docstring] Function 'check_compatibility' has no docstring.

### `src/requests/_types.py`

- 🟡 **line 29** [missing-docstring] Function 'read' has no docstring.
- 🟡 **line 39** [missing-docstring] Function 'items' has no docstring.

### `src/requests/adapters.py`

- 🟡 **line 66** [missing-docstring] Function 'SOCKSProxyManager' has no docstring.
- 🟠 **line 128** [too-many-args] Function 'send' takes 7 arguments (threshold: 5).
- 🟠 **line 307** [long-function] Function 'cert_verify' is 56 lines long (threshold: 50).
- 🟠 **line 455** [long-function] Function 'get_connection_with_tls_context' is 55 lines long (threshold: 50).
- 🟠 **line 634** [long-function] Function 'send' is 114 lines long (threshold: 50).
- 🟠 **line 634** [too-many-args] Function 'send' takes 7 arguments (threshold: 5).
- 🟡 **line 715** [todo-comment] Unresolved TODO/FIXME left in code.

### `src/requests/api.py`

- 🟡 **line 29** [long-line] Line is 139 characters (threshold: 120).
- 🟡 **line 38** [long-line] Line is 133 characters (threshold: 120).
- 🟡 **line 41** [long-line] Line is 123 characters (threshold: 120).
- 🟡 **line 48** [long-line] Line is 136 characters (threshold: 120).

### `src/requests/auth.py`

- 🟡 **line 147** [missing-docstring] Function 'init_per_thread_state' has no docstring.
- 🟠 **line 157** [long-function] Function 'build_digest_header' is 109 lines long (threshold: 50).
- 🟡 **line 176** [missing-docstring] Function 'md5_utf8' has no docstring.
- 🟡 **line 184** [missing-docstring] Function 'sha_utf8' has no docstring.
- 🟡 **line 192** [missing-docstring] Function 'sha256_utf8' has no docstring.
- 🟡 **line 200** [missing-docstring] Function 'sha512_utf8' has no docstring.
- 🟡 **line 210** [missing-docstring] Function 'KD' has no docstring.
- 🟡 **line 239** [long-line] Line is 122 characters (threshold: 120).

## Planning Trace

1. **Parse and validate the target GitHub repository URL.**  
   _why:_ We can't do anything else until we know a well-formed owner/repo exists; failing fast here avoids wasted API calls later.
2. **Fetch repository metadata (default branch, language, size).**  
   _why:_ We need the default branch name before we can list or fetch any files.
3. **Fetch the full file tree and select source files to review.**  
   _why:_ One recursive API call lists every file cheaply; we then filter to source files (.py) and cap the count so the review stays fast.
4. **Fetch the content of each selected file.**  
   _why:_ Content is fetched from the raw CDN, not the metered API, to conserve rate limit. Missing files are handled via fallback candidates.
5. **Run static analysis on each fetched file.**  
   _why:_ Real AST parsing catches structural issues (long functions, bare excepts, missing docstrings, etc.) that a keyword search would miss.
6. **Aggregate findings into per-file and overall quality scores.**  
   _why:_ A single number makes the report skimmable; the itemized issues underneath it make the score explainable.
7. **Generate the final structured Markdown + JSON report.**  
   _why:_ Two formats: Markdown for a human reviewer, JSON for downstream tooling to consume programmatically.
