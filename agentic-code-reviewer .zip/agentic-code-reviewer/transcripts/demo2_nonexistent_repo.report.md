# Code Quality Report

**Goal:** Review the code quality of the GitHub repository 'https://github.com/anthropic-does-not-exist/fake-repo-xyz-123' and suggest fixes.

**Status:** ❌ Failed  **Duration:** 0.11s

## Error

> Repository not found or inaccessible: 404 Not Found: https://api.github.com/repos/anthropic-does-not-exist/fake-repo-xyz-123. Verify the URL points to an existing public repository.

## Planning Trace

1. **Parse and validate the target GitHub repository URL.**  
   _why:_ We can't do anything else until we know a well-formed owner/repo exists; failing fast here avoids wasted API calls later.
2. **Fetch repository metadata (default branch, language, size).**  
   _why:_ We need the default branch name before we can list or fetch any files.
3. **Fetch the full file tree and select source files to review.**  
   _why:_ One recursive API call lists every file cheaply; we then filter to source files (.py) and cap the count so the review stays fast.
4. **Fetch the content of each selected file.**  
   _why:_ Content is fetched from the raw CDN, not the metered API, to conserve rate limit. Missing files are handled via fallback candidates.
5. **Run static analysis on each fetched file.**  
   _why:_ Real AST parsing catches structural issues (long functions, bare excepts, missing docstrings, etc.) that a keyword search would miss.
6. **Aggregate findings into per-file and overall quality scores.**  
   _why:_ A single number makes the report skimmable; the itemized issues underneath it make the score explainable.
7. **Generate the final structured Markdown + JSON report.**  
   _why:_ Two formats: Markdown for a human reviewer, JSON for downstream tooling to consume programmatically.
