"""
Orchestrator
============
Runs the plan produced by Planner, step by step, calling the real tools
and logging everything (this log IS the "sample run transcript" the
assignment asks for). This is where the agent's error-handling and
self-correction logic actually lives.

Self-correction strategies implemented here (each is exercised by one of
the sample transcripts):

  1. RepoNotFoundError on the *repository itself* -> unrecoverable, but the
     agent does NOT crash: it stops cleanly and produces a report that
     explains exactly what went wrong. (See transcript 02.)

  2. A specific file 404s when we try to fetch it (e.g. we guessed
     "main.py" but the repo actually uses "app.py") -> the agent retries
     with a short list of fallback candidate filenames before giving up
     on that one file. (See transcript 03.)

  3. A file's content isn't valid Python (parse error) -> AnalyzerTool
     already returns a graceful FileAnalysis with parse_error set instead
     of raising; the orchestrator logs it as a warning and continues with
     the remaining files rather than aborting the whole run.

  4. Transient network errors / GitHub rate limiting -> handled inside
     GitHubTool itself via retry-with-backoff (see github_tool.py).
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field

from .planner import Planner, Step
from .tools.github_tool import GitHubTool, RepoNotFoundError, GitHubToolError
from .tools.analyzer_tool import AnalyzerTool, FileAnalysis
from .tools.calculator_tool import CalculatorTool

logger = logging.getLogger("agent")

SOURCE_EXTENSIONS = (".py",)
MAX_FILES_TO_REVIEW = 12
MAX_FILE_SIZE_BYTES = 60_000  # skip huge generated files
SKIP_DIR_HINTS = ("test", "tests", "vendor", "migrations", "node_modules", "__pycache__")

ENTRYPOINT_FALLBACKS = ["main.py", "app.py", "__init__.py", "run.py", "cli.py"]


@dataclass
class RunResult:
    goal: str
    success: bool
    plan: list[Step] = field(default_factory=list)
    repo_meta: dict | None = None
    file_analyses: list[FileAnalysis] = field(default_factory=list)
    file_scores: dict[str, float] = field(default_factory=dict)
    overall_score: float | None = None
    warnings: list[str] = field(default_factory=list)
    error: str | None = None
    duration_seconds: float = 0.0


class Orchestrator:

    def __init__(self):
        self.planner = Planner()
        self.github = GitHubTool()
        self.analyzer = AnalyzerTool()
        self.calculator = CalculatorTool()

    def run(self, goal: str, repo_url: str) -> RunResult:
        start = time.time()
        logger.info("GOAL: %s", goal)
        result = RunResult(goal=goal, success=False)

        plan = self.planner.plan(goal)
        result.plan = plan
        logger.info("---- PLAN (%d steps) ----", len(plan))
        for step in plan:
            logger.info("  [%d] %s | why: %s", step.id, step.description, step.rationale)

        try:
            owner, repo = self._exec_parse_target(repo_url)
            meta = self._exec_fetch_metadata(owner, repo)
            result.repo_meta = meta
            branch = meta["default_branch"]

            candidate_files = self._exec_fetch_tree(owner, repo, branch)
            contents = self._exec_fetch_contents(owner, repo, branch, candidate_files, result)
            analyses = self._exec_analyze(contents, result)
            result.file_analyses = analyses
            self._exec_score(analyses, result)

            result.success = True

        except RepoNotFoundError as e:
            logger.error("UNRECOVERABLE: %s", e)
            result.error = (
                f"Repository not found or inaccessible: {e}. "
                f"Verify the URL points to an existing public repository."
            )
        except GitHubToolError as e:
            logger.error("UNRECOVERABLE: %s", e)
            result.error = f"GitHub API error: {e}"
        except Exception as e:  # last-resort guard so the agent never hard-crashes
            logger.exception("Unexpected error")
            result.error = f"Unexpected error: {type(e).__name__}: {e}"

        result.duration_seconds = round(time.time() - start, 2)
        logger.info("---- DONE (success=%s, %.2fs) ----", result.success, result.duration_seconds)
        return result

    # ---------------- individual plan-step executors ----------------

    def _exec_parse_target(self, repo_url: str):
        logger.info("STEP 1: parsing target '%s'", repo_url)
        owner, repo = self.github.parse_repo_url(repo_url)
        logger.info("  -> owner=%s repo=%s", owner, repo)
        return owner, repo

    def _exec_fetch_metadata(self, owner: str, repo: str) -> dict:
        logger.info("STEP 2: fetching repo metadata")
        meta = self.github.get_repo_metadata(owner, repo)
        logger.info("  -> %s", meta)
        return meta

    def _exec_fetch_tree(self, owner: str, repo: str, branch: str) -> list[str]:
        logger.info("STEP 3: fetching file tree")
        tree = self.github.get_file_tree(owner, repo, branch)
        candidates = [
            f.path for f in tree
            if f.path.endswith(SOURCE_EXTENSIONS)
            and f.size_bytes <= MAX_FILE_SIZE_BYTES
            and not any(hint in f.path.lower() for hint in SKIP_DIR_HINTS)
        ]
        selected = candidates[:MAX_FILES_TO_REVIEW]
        logger.info("  -> %d source files found, reviewing %d", len(candidates), len(selected))
        return selected

    def _exec_fetch_contents(self, owner, repo, branch, paths, result: RunResult) -> dict[str, str]:
        logger.info("STEP 4: fetching file contents")
        contents = {}
        for path in paths:
            text = self.github.get_file_content(owner, repo, branch, path)
            if text is None:
                # Self-correction: this specific path 404'd. Try plausible
                # alternates ONLY if it looked like an entrypoint guess;
                # otherwise just skip this one file and keep going.
                logger.warning("  file '%s' returned 404, attempting recovery", path)
                recovered = self._recover_missing_file(owner, repo, branch, path)
                if recovered:
                    contents[recovered[0]] = recovered[1]
                    result.warnings.append(
                        f"'{path}' was missing; recovered by using '{recovered[0]}' instead."
                    )
                else:
                    result.warnings.append(f"'{path}' could not be fetched; skipped.")
                continue
            contents[path] = text
        logger.info("  -> fetched %d/%d files", len(contents), len(paths))
        return contents

    def _recover_missing_file(self, owner, repo, branch, missing_path):
        directory = missing_path.rsplit("/", 1)[0] if "/" in missing_path else ""
        for candidate_name in ENTRYPOINT_FALLBACKS:
            candidate_path = f"{directory}/{candidate_name}" if directory else candidate_name
            if candidate_path == missing_path:
                continue
            text = self.github.get_file_content(owner, repo, branch, candidate_path)
            if text is not None:
                logger.info("  -> recovered via fallback candidate '%s'", candidate_path)
                return candidate_path, text
        return None

    def _exec_analyze(self, contents: dict[str, str], result: RunResult) -> list[FileAnalysis]:
        logger.info("STEP 5: running static analysis")
        analyses = []
        for path, source in contents.items():
            analysis = self.analyzer.analyze_file(path, source)
            if analysis.parse_error:
                # Self-correction: don't abort the run over one bad file.
                logger.warning("  '%s' failed to parse (%s) -- skipping analysis for it",
                                path, analysis.parse_error)
                result.warnings.append(f"'{path}' skipped: {analysis.parse_error}")
            else:
                logger.info("  '%s' -> %d issues", path, len(analysis.issues))
            analyses.append(analysis)
        return analyses

    def _exec_score(self, analyses: list[FileAnalysis], result: RunResult):
        logger.info("STEP 6: scoring")
        file_scores = {}
        for a in analyses:
            if a.parse_error:
                continue
            breakdown = self.calculator.severity_breakdown(a.issues)
            file_scores[a.path] = self.calculator.score_file(breakdown, a.lines_of_code)
        result.file_scores = file_scores
        result.overall_score = self.calculator.aggregate_repo_score(list(file_scores.values()))
        logger.info("  -> overall score: %s/100", result.overall_score)
