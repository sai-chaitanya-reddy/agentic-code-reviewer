"""
Reporter
========
Step 7 of the plan. Turns a RunResult into the two required output
formats: a human-readable Markdown report and a machine-readable JSON
report (structured output, per the assignment's requirement (e)).
"""

from __future__ import annotations

import json
import dataclasses
from .orchestrator import RunResult


def to_json(result: RunResult) -> str:
    def default(o):
        if dataclasses.is_dataclass(o):
            return dataclasses.asdict(o)
        return str(o)
    return json.dumps(dataclasses.asdict(result), default=default, indent=2)


def to_markdown(result: RunResult) -> str:
    lines = []
    lines.append(f"# Code Quality Report\n")
    lines.append(f"**Goal:** {result.goal}\n")
    lines.append(f"**Status:** {'✅ Success' if result.success else '❌ Failed'}  "
                 f"**Duration:** {result.duration_seconds}s\n")

    if result.error:
        lines.append("## Error\n")
        lines.append(f"> {result.error}\n")

    if result.repo_meta:
        m = result.repo_meta
        lines.append("## Repository\n")
        lines.append(f"- **Name:** {m.get('full_name')}")
        lines.append(f"- **Description:** {m.get('description') or '—'}")
        lines.append(f"- **Primary language:** {m.get('language') or '—'}")
        lines.append(f"- **Stars:** {m.get('stars')}\n")

    if result.overall_score is not None:
        lines.append(f"## Overall Quality Score: **{result.overall_score}/100**\n")

    if result.file_scores:
        lines.append("## Per-file Scores\n")
        lines.append("| File | Score | Issues |")
        lines.append("|---|---|---|")
        by_path = {a.path: a for a in result.file_analyses}
        for path, score in sorted(result.file_scores.items(), key=lambda x: x[1]):
            n_issues = len(by_path[path].issues) if path in by_path else "—"
            lines.append(f"| `{path}` | {score} | {n_issues} |")
        lines.append("")

    issues_exist = any(a.issues for a in result.file_analyses)
    if issues_exist:
        lines.append("## Issues Found\n")
        for a in result.file_analyses:
            if not a.issues:
                continue
            lines.append(f"### `{a.path}`\n")
            for issue in sorted(a.issues, key=lambda i: i.line):
                icon = {"high": "🔴", "medium": "🟠", "low": "🟡"}[issue.severity]
                lines.append(f"- {icon} **line {issue.line}** [{issue.rule}] {issue.message}")
            lines.append("")

    if result.warnings:
        lines.append("## Warnings / Self-Corrections During This Run\n")
        for w in result.warnings:
            lines.append(f"- ⚠️ {w}")
        lines.append("")

    if result.plan:
        lines.append("## Planning Trace\n")
        for step in result.plan:
            lines.append(f"{step.id}. **{step.description}**  \n   _why:_ {step.rationale}")
        lines.append("")

    return "\n".join(lines)
