"""
CalculatorTool
==============
Tool #3 (bonus, beyond the required two). Pure arithmetic, no I/O -- turns
the raw list of issues from AnalyzerTool into a single 0-100 quality score
per file and for the repo overall. Kept separate from AnalyzerTool
deliberately: analysis (finding facts) and scoring (applying a policy to
those facts) are different concerns, and a reviewer might want to change
the scoring weights without touching the parser.
"""

from __future__ import annotations

SEVERITY_WEIGHTS = {"high": 8, "medium": 4, "low": 1}


class CalculatorTool:

    def score_file(self, num_issues_by_severity: dict[str, int], lines_of_code: int) -> float:
        """100 = no issues. Each issue deducts points by severity, scaled
        gently by file size so a 500-line file isn't unfairly punished
        compared to a 20-line one."""
        deduction = sum(
            count * SEVERITY_WEIGHTS.get(sev, 1)
            for sev, count in num_issues_by_severity.items()
        )
        size_factor = max(lines_of_code, 20) / 20  # bigger files absorb more deduction
        score = 100 - (deduction / size_factor)
        return round(max(0.0, min(100.0, score)), 1)

    def aggregate_repo_score(self, file_scores: list[float]) -> float:
        if not file_scores:
            return 0.0
        return round(sum(file_scores) / len(file_scores), 1)

    def severity_breakdown(self, all_issues) -> dict[str, int]:
        out = {"high": 0, "medium": 0, "low": 0}
        for issue in all_issues:
            out[issue.severity] = out.get(issue.severity, 0) + 1
        return out
