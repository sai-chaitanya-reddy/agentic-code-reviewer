"""
AnalyzerTool
============
Tool #2: a "code executor" tool per the assignment's examples. It parses
Python source with the `ast` module (Python's real, built-in parser -- this
is genuine static analysis, not a keyword-search gimmick) and reports
concrete, explainable issues.

Design note: if a file fails to parse (e.g. it's not actually valid Python,
or uses syntax this analyzer doesn't handle), we do NOT crash the whole
pipeline. We record the failure and move on -- this is one of the agent's
self-correction points, exercised for real whenever a repo has a broken
or non-Python file in it.
"""

from __future__ import annotations

import ast
from dataclasses import dataclass, field


SEVERITY_WEIGHTS = {"high": 8, "medium": 4, "low": 1}


@dataclass
class Issue:
    file: str
    line: int
    severity: str  # "high" | "medium" | "low"
    rule: str
    message: str


@dataclass
class FileAnalysis:
    path: str
    lines_of_code: int
    issues: list[Issue] = field(default_factory=list)
    parse_error: str | None = None


class AnalyzerTool:
    """Runs static-analysis checks on a single file's source text."""

    MAX_FUNCTION_LINES = 50
    MAX_ARGS = 5
    MAX_LINE_LENGTH = 120

    def analyze_file(self, path: str, source: str) -> FileAnalysis:
        loc = len([ln for ln in source.splitlines() if ln.strip()])
        try:
            tree = ast.parse(source, filename=path)
        except SyntaxError as e:
            # Graceful degradation instead of a crash -- self-correction case.
            return FileAnalysis(
                path=path,
                lines_of_code=loc,
                parse_error=f"SyntaxError: {e.msg} (line {e.lineno})",
            )

        issues: list[Issue] = []
        issues += self._check_long_lines(path, source)
        issues += self._check_todo_comments(path, source)

        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                issues += self._check_function(path, node)
            if isinstance(node, ast.ExceptHandler):
                issues += self._check_bare_except(path, node)
            if isinstance(node, ast.ImportFrom):
                issues += self._check_wildcard_import(path, node)

        return FileAnalysis(path=path, lines_of_code=loc, issues=issues)

    # ---- individual checks (each one is small and independently testable) ----

    def _check_function(self, path: str, node) -> list[Issue]:
        out = []
        has_docstring = ast.get_docstring(node) is not None
        if not has_docstring and not node.name.startswith("_"):
            out.append(Issue(
                path, node.lineno, "low", "missing-docstring",
                f"Function '{node.name}' has no docstring."
            ))
        n_lines = (node.end_lineno or node.lineno) - node.lineno
        if n_lines > self.MAX_FUNCTION_LINES:
            out.append(Issue(
                path, node.lineno, "medium", "long-function",
                f"Function '{node.name}' is {n_lines} lines long "
                f"(threshold: {self.MAX_FUNCTION_LINES})."
            ))
        n_args = len(node.args.args)
        if n_args > self.MAX_ARGS:
            out.append(Issue(
                path, node.lineno, "medium", "too-many-args",
                f"Function '{node.name}' takes {n_args} arguments "
                f"(threshold: {self.MAX_ARGS})."
            ))
        for default in node.args.defaults:
            if isinstance(default, (ast.List, ast.Dict, ast.Set)):
                out.append(Issue(
                    path, node.lineno, "high", "mutable-default-arg",
                    f"Function '{node.name}' uses a mutable default argument "
                    f"(classic Python bug source)."
                ))
        return out

    def _check_bare_except(self, path: str, node) -> list[Issue]:
        if node.type is None:
            return [Issue(
                path, node.lineno, "high", "bare-except",
                "Bare 'except:' clause silently swallows all exceptions, "
                "including KeyboardInterrupt/SystemExit."
            )]
        return []

    def _check_wildcard_import(self, path: str, node) -> list[Issue]:
        if any(alias.name == "*" for alias in node.names):
            return [Issue(
                path, node.lineno, "medium", "wildcard-import",
                f"'from {node.module} import *' pollutes the namespace and "
                f"hides where names come from."
            )]
        return []

    def _check_long_lines(self, path: str, source: str) -> list[Issue]:
        out = []
        for i, line in enumerate(source.splitlines(), start=1):
            if len(line) > self.MAX_LINE_LENGTH:
                out.append(Issue(
                    path, i, "low", "long-line",
                    f"Line is {len(line)} characters "
                    f"(threshold: {self.MAX_LINE_LENGTH})."
                ))
        return out

    def _check_todo_comments(self, path: str, source: str) -> list[Issue]:
        out = []
        for i, line in enumerate(source.splitlines(), start=1):
            stripped = line.strip()
            if stripped.startswith("#") and ("TODO" in stripped or "FIXME" in stripped):
                out.append(Issue(
                    path, i, "low", "todo-comment",
                    "Unresolved TODO/FIXME left in code."
                ))
        return out
