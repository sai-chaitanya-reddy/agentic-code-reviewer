"""
GitHubTool
==========
Tool #1: a live data-fetching tool. Talks to the real GitHub REST API
(api.github.com) and the raw content CDN (raw.githubusercontent.com).

No API key required for public repos (subject to GitHub's unauthenticated
rate limit of 60 requests/hour/IP). To keep well under that limit we:
  - use ONE API call to list the entire file tree recursively
  - fetch file *contents* from raw.githubusercontent.com, which does not
    count against the api.github.com rate limit at all.

This tool raises the custom exceptions below instead of generic ones, so
the orchestrator can tell "repo doesn't exist" apart from "network hiccup,
try again" apart from "we got rate limited" -- each deserves a different
self-correction strategy.
"""

from __future__ import annotations

import re
import time
import requests
from dataclasses import dataclass
from typing import Optional


class GitHubToolError(Exception):
    """Base class for all errors raised by this tool."""


class RepoNotFoundError(GitHubToolError):
    """The repository (or a specific file in it) does not exist. Do not retry."""


class RateLimitedError(GitHubToolError):
    """GitHub told us to slow down. Worth a backoff-and-retry."""


class TransientNetworkError(GitHubToolError):
    """A connection/timeout blip. Worth retrying."""


@dataclass
class RepoFile:
    path: str
    size_bytes: int


class GitHubTool:
    """Fetches repository data from the real GitHub API."""

    API_ROOT = "https://api.github.com"
    RAW_ROOT = "https://raw.githubusercontent.com"

    def __init__(self, timeout: int = 10, max_retries: int = 2):
        self.timeout = timeout
        self.max_retries = max_retries
        self.session = requests.Session()
        self.session.headers.update({
            "Accept": "application/vnd.github+json",
            "User-Agent": "agentic-code-reviewer-intern-project",
        })

    # ---------- step 1: turn a URL into (owner, repo) ----------
    @staticmethod
    def parse_repo_url(url: str) -> tuple[str, str]:
        """
        Accepts things like:
          https://github.com/psf/requests
          github.com/psf/requests
          psf/requests
        Returns (owner, repo). Raises ValueError if it really can't be parsed
        -- this is a *planning-time* validation, not a network call.
        """
        url = url.strip().rstrip("/")
        url = re.sub(r"^https?://", "", url)
        url = re.sub(r"^www\.", "", url)
        url = re.sub(r"^github\.com/", "", url)
        parts = url.split("/")
        if len(parts) < 2 or not parts[0] or not parts[1]:
            raise ValueError(
                f"Could not parse a GitHub owner/repo out of '{url}'. "
                f"Expected something like 'owner/repo' or a full github.com URL."
            )
        owner, repo = parts[0], parts[1]
        repo = repo.removesuffix(".git")
        return owner, repo

    # ---------- internal: a GET with retry/backoff + typed errors ----------
    def _get(self, url: str, allow_404: bool = False) -> Optional[requests.Response]:
        last_err: Optional[Exception] = None
        for attempt in range(self.max_retries + 1):
            try:
                resp = self.session.get(url, timeout=self.timeout)
            except (requests.ConnectionError, requests.Timeout) as e:
                last_err = e
                time.sleep(0.5 * (2 ** attempt))  # exponential backoff
                continue

            if resp.status_code == 200:
                return resp
            if resp.status_code == 404:
                if allow_404:
                    return None
                raise RepoNotFoundError(f"404 Not Found: {url}")
            if resp.status_code in (403, 429):
                remaining = resp.headers.get("X-RateLimit-Remaining")
                if remaining == "0":
                    raise RateLimitedError(
                        f"GitHub API rate limit hit while calling {url}"
                    )
                # secondary rate limit / abuse detection -> brief backoff, retry
                time.sleep(1.0 * (2 ** attempt))
                last_err = RateLimitedError(f"403 on {url}")
                continue
            if 500 <= resp.status_code < 600:
                last_err = TransientNetworkError(f"{resp.status_code} on {url}")
                time.sleep(0.5 * (2 ** attempt))
                continue
            # anything else unexpected
            raise GitHubToolError(f"Unexpected status {resp.status_code} on {url}")

        raise last_err or TransientNetworkError(f"Failed to GET {url} after retries")

    # ---------- step 2: repo metadata ----------
    def get_repo_metadata(self, owner: str, repo: str) -> dict:
        url = f"{self.API_ROOT}/repos/{owner}/{repo}"
        resp = self._get(url)
        data = resp.json()
        return {
            "full_name": data.get("full_name"),
            "description": data.get("description"),
            "default_branch": data.get("default_branch", "main"),
            "stars": data.get("stargazers_count", 0),
            "language": data.get("language"),
            "size_kb": data.get("size", 0),
        }

    # ---------- step 3: full file tree in one call ----------
    def get_file_tree(self, owner: str, repo: str, branch: str) -> list[RepoFile]:
        url = f"{self.API_ROOT}/repos/{owner}/{repo}/git/trees/{branch}?recursive=1"
        resp = self._get(url)
        data = resp.json()
        if data.get("truncated"):
            # GitHub silently truncates huge trees; worth surfacing to the report
            pass
        files = []
        for item in data.get("tree", []):
            if item.get("type") == "blob":
                files.append(RepoFile(path=item["path"], size_bytes=item.get("size", 0)))
        return files

    # ---------- step 4: fetch one file's content ----------
    def get_file_content(self, owner: str, repo: str, branch: str, path: str) -> Optional[str]:
        """Returns None (not an exception) if the specific file 404s -- this is
        the expected, recoverable case the orchestrator self-corrects around."""
        url = f"{self.RAW_ROOT}/{owner}/{repo}/{branch}/{path}"
        resp = self._get(url, allow_404=True)
        if resp is None:
            return None
        try:
            return resp.text
        except Exception:
            return None
