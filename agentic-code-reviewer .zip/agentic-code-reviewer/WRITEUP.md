# Write-up

## Design decisions

**Domain: GitHub code-quality reviewer.** I chose this over the other
example prompts because it lets every tool call be genuinely live — no
synthetic data, no mocked APIs. The agent hits the real GitHub REST API
and the real raw-content CDN, and runs real AST-based static analysis on
whatever it downloads. I felt this would demonstrate tool orchestration
more convincingly than a task where the "data source" has to be simulated.

**Separating Planner / Orchestrator / Tools / Reporter.** Each has exactly
one job: the Planner decides *what* to do and *why*, the Orchestrator
decides *how* to do it robustly (retries, fallbacks, logging), the Tools
do one concrete thing each, and the Reporter only formats. This made the
error-handling logic much easier to reason about and test in isolation —
e.g. `AnalyzerTool` never has to know that a file might be unfetchable,
and `GitHubTool` never has to know what "quality" means.

**Deterministic planning by default, LLM-assisted as an opt-in.** Real
planning models are the obvious "agentic" choice, but requiring an API key
would make the submission unrunnable for a reviewer without one, and would
make every demo run non-reproducible. So the default planner is a fixed,
well-reasoned template (with an explained rationale per step), and I added
an optional path that calls Claude via `api.anthropic.com` to generate the
plan dynamically if `ANTHROPIC_API_KEY` is set — with an automatic fallback
to the deterministic plan if that call fails for any reason. I see this as
a reliability decision, not a shortcut: a planning step that can silently
take down the whole agent is worse than a good static one.

**Three distinct tools, not two.** `GitHubTool` (data), `AnalyzerTool`
(real static analysis via Python's `ast` module — this is the "code
executor" tool from the assignment's examples), and `CalculatorTool`
(pure scoring arithmetic). I split scoring out of analysis specifically so
the scoring *policy* (severity weights, size normalization) can change
without touching the parser.

**Fetching content from the raw CDN, not the metered API.** Unauthenticated
GitHub API calls are capped at 60/hour. Listing a repo's entire file tree
costs exactly one API call (`git/trees?recursive=1`); fetching each file's
actual content via `raw.githubusercontent.com` costs nothing against that
limit. This let the agent review real, large repos (e.g. `psf/requests`)
without hitting rate limits during testing.

## Self-correction, concretely

Three distinct failure modes are handled differently on purpose, because
they call for different responses:

1. **The whole repo is unreachable** (typo'd URL, private repo, deleted
   repo) → unrecoverable, but the agent still produces a clean, explained
   failure report instead of a stack trace. (`transcripts/demo2_*`)
2. **One specific file 404s** (agent guessed a filename that turns out to
   be wrong) → recoverable — the agent tries a short list of common
   entrypoint filenames in the same directory before giving up on just
   that file, and logs what it did. (`transcripts/demo3_*`)
3. **A fetched file isn't valid Python** → recoverable — `AnalyzerTool`
   returns a structured parse error instead of raising, and the
   orchestrator logs a warning and continues analyzing the remaining files.

## Limitations

- Only reviews `.py` files, and caps at 12 files per run — a real product
  would need language-agnostic analysis and pagination/streaming for large
  repos rather than a hard cap.
- The static analysis rule set is intentionally small and readable (7
  rules) rather than exhaustive — a real version would likely wrap `pylint`
  or `radon` for cyclomatic complexity, at the cost of an extra dependency.
- No persistence between runs — each run is stateless. A longer-running
  agent (e.g. "review every PR") would need a datastore for prior results.
- No authentication support for private repos.

## What I'd do differently with more time

- Add a GitHub token option to raise the rate limit and support private
  repos.
- Let the LLM-assisted planner also choose *which* files to prioritize
  (e.g. "review the files most recently changed") instead of the
  orchestrator's fixed first-N selection.
- Wrap `radon` for real cyclomatic-complexity scoring instead of the
  line-count heuristic currently used for "long function."
- Add an integration test that runs against a small fixture repo checked
  into the test suite itself, so tests don't depend on GitHub's uptime.
