import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from agent.tools.calculator_tool import CalculatorTool
from agent.tools.github_tool import GitHubTool


def test_no_issues_scores_100():
    c = CalculatorTool()
    assert c.score_file({"high": 0, "medium": 0, "low": 0}, lines_of_code=100) == 100.0


def test_high_severity_penalized_more_than_low():
    c = CalculatorTool()
    score_high = c.score_file({"high": 1, "medium": 0, "low": 0}, lines_of_code=100)
    score_low = c.score_file({"high": 0, "medium": 0, "low": 1}, lines_of_code=100)
    assert score_high < score_low


def test_score_never_negative():
    c = CalculatorTool()
    score = c.score_file({"high": 100, "medium": 100, "low": 100}, lines_of_code=20)
    assert score == 0.0


def test_aggregate_is_average():
    c = CalculatorTool()
    assert c.aggregate_repo_score([80.0, 100.0]) == 90.0


def test_aggregate_empty_list():
    c = CalculatorTool()
    assert c.aggregate_repo_score([]) == 0.0


@pytest.mark.parametrize("url,expected", [
    ("https://github.com/psf/requests", ("psf", "requests")),
    ("github.com/psf/requests", ("psf", "requests")),
    ("psf/requests", ("psf", "requests")),
    ("https://github.com/psf/requests.git", ("psf", "requests")),
    ("https://github.com/psf/requests/", ("psf", "requests")),
])
def test_parse_repo_url_variants(url, expected):
    assert GitHubTool.parse_repo_url(url) == expected


def test_parse_repo_url_invalid_raises():
    with pytest.raises(ValueError):
        GitHubTool.parse_repo_url("not-a-valid-repo-string")
