import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from agent.tools.analyzer_tool import AnalyzerTool


def test_missing_docstring_detected():
    src = "def foo(x):\n    return x\n"
    result = AnalyzerTool().analyze_file("t.py", src)
    assert any(i.rule == "missing-docstring" for i in result.issues)


def test_docstring_present_no_flag():
    src = 'def foo(x):\n    """Does a thing."""\n    return x\n'
    result = AnalyzerTool().analyze_file("t.py", src)
    assert not any(i.rule == "missing-docstring" for i in result.issues)


def test_bare_except_detected():
    src = "try:\n    x = 1\nexcept:\n    pass\n"
    result = AnalyzerTool().analyze_file("t.py", src)
    assert any(i.rule == "bare-except" and i.severity == "high" for i in result.issues)


def test_mutable_default_arg_detected():
    src = "def foo(items=[]):\n    return items\n"
    result = AnalyzerTool().analyze_file("t.py", src)
    assert any(i.rule == "mutable-default-arg" for i in result.issues)


def test_too_many_args_detected():
    src = "def foo(a, b, c, d, e, f):\n    '''doc'''\n    return a\n"
    result = AnalyzerTool().analyze_file("t.py", src)
    assert any(i.rule == "too-many-args" for i in result.issues)


def test_wildcard_import_detected():
    src = "from os import *\n"
    result = AnalyzerTool().analyze_file("t.py", src)
    assert any(i.rule == "wildcard-import" for i in result.issues)


def test_syntax_error_does_not_crash():
    src = "def foo(:\n    pass\n"  # invalid syntax
    result = AnalyzerTool().analyze_file("t.py", src)
    assert result.parse_error is not None
    assert result.issues == []


def test_clean_code_has_no_issues():
    src = 'def add(a, b):\n    """Add two numbers."""\n    return a + b\n'
    result = AnalyzerTool().analyze_file("t.py", src)
    assert result.issues == []
    assert result.parse_error is None
